﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace org.foi.uzdiz.dzunec.dz2.dzunec_zadaca_2
{
    public static class Log
    {
        private static TextWriter _current;
        private static string nazivDatoteke;

        private class OutputWriter : TextWriter
        {
            public override Encoding Encoding
            {
                get
                {
                    return _current.Encoding;
                }
            }

            public override void WriteLine(string value)
            {
                _current.WriteLine(value);
                File.AppendAllLines(nazivDatoteke, new string[] { value });
            }

            public override void WriteLine(object value)
            {
                _current.Write(value);
                File.AppendAllLines(nazivDatoteke, new string[] { value.ToString() });
            }

            public override void WriteLine()
            {
                _current.WriteLine();
                File.AppendAllLines(nazivDatoteke, new string[] { "\n" });

            }

            public override void Write(object value)
            {
                _current.Write(value);
                File.AppendAllText(nazivDatoteke, value.ToString());
            }

            public override void Write(string value)
            {
                _current.Write(value);
                File.AppendAllText(nazivDatoteke, value);
            }

        }

        public static void Init(string naziv)
        {
            nazivDatoteke = naziv;
            if (File.Exists(nazivDatoteke))
            {
                File.Delete(nazivDatoteke);
            }
            _current = Console.Out;
            Console.SetOut(new OutputWriter());
        }
    }
}
